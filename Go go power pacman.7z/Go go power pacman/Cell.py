import pygame
import sys

size = width, height = 768, 1008
black = 0, 0, 0
blue = 0, 0, 255
yellow = 255, 200, 30
white = 255, 255, 255


class Cell:
    def __init__(self, color=blue, x=None, y=None, cell_size=48, line_width=None, type=None, dot_size=4, \
                 super_dot_size=10, isDot=True, color_dot=yellow, color_super_dot=white):
        self.color = color
        self.color_dot = color_dot
        self.color_super_dot = color_super_dot
        self.x = x
        self.y = y
        self.centre = [self.x + cell_size // 2, self.y + cell_size // 2]
        self.cell_size = cell_size
        self.dot_size = dot_size
        self.super_dot_size = super_dot_size
        self.isDot = isDot
        if (type == 2):
            self.isSuper_Dot = True
        else:
            self.isSuper_Dot = False
        self.line_width = line_width
        self.rect1 = (self.x, self.y, self.cell_size, self.cell_size)
        self.x_dot = x + 20
        self.y_dot = y + 20
        self.dot_Rect = (self.x_dot, self.y_dot, self.dot_size, self.dot_size)
        self.super_dot_Rect = (self.x_dot, self.y_dot, self.super_dot_size, self.super_dot_size)
        self.inside_cell_size = 24
        self.rect2 = pygame.Rect(self.x + 18, self.y + 12, self.inside_cell_size, self.inside_cell_size)
        self.type = type

    def process_draw(self, screen):
        if self.type == 1:
            pygame.draw.rect(screen, self.color, (self.x, self.y, self.cell_size, self.cell_size), self.line_width)
        if (self.type == 0) and (self.isDot is True):
            pygame.draw.rect(screen, self.color_dot, self.dot_Rect, self.line_width)
        if (self.isSuper_Dot is True):
            pygame.draw.circle(screen, self.color_super_dot, self.centre, 5, self.line_width)
