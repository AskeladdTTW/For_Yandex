import pygame
from random import randint


class Fruit:
    image = pygame.image.load('images/fruit1.png')

    def __init__(self, x: int = None, y: int = None):
        self.rect = self.image.get_rect()
        if x is None:
            x = 0
            y = 0
        self.rect.x = x
        self.rect.y = y
        self.can_you_eat_me = False
        self.ogr = 700

    def process_draw(self, screen):
        screen.blit(self.image, self.rect)

    def respawn(self):
        self.rect.x, self.rect.y = 4 + 48 * randint(2, 14), 4 + 48 * randint(2, 14)

    def spawn(self):
        self.rect.x, self.rect.y = 4 + 10 * 48, 4 + 10 * 48
