import pygame
import math
from random import choice


class Ghost3:
    image = pygame.image.load('images/gh_b_up_1.png')
    images_top = [pygame.image.load('images/gh_b_up_1.png'),
                  pygame.image.load('images/gh_b_up_2.png')]
    images_bot = [pygame.image.load('images/gh_b_down_1.png'),
                  pygame.image.load('images/gh_b_down_2.png')]
    images_lef = [pygame.image.load('images/gh_b_left_1.png'),
                  pygame.image.load('images/gh_b_left_2.png')]
    images_rig = [pygame.image.load('images/gh_b_right_1.png'),
                  pygame.image.load('images/gh_b_right_2.png')]
    images_fear = [pygame.image.load('images/gh_fear_1.png'),
                   pygame.image.load('images/gh_fear_2.png')]
    speed = 1
    motion = [0, 0]

    maxFrames = 15
    frame = 0

    max_fear = 60 * 5
    fear = 0

    def __init__(self, x: int = None, y: int = None, sp: int = None):
        self.rect = self.image.get_rect()
        if sp:
            self.speed = sp
        if x is None:
            x = 0
            y = 0
        self.rect.x = x
        self.rect.y = y
        self.is_fear = False
        self.rip = False
        self.my_rip_timer = 0
        self.max_rip = 60 * 10
        self.prev_direction = -1
        self.direction = -1
        self.status = 0
        self.distances = [10000, 10000, 10000, 10000]
        self.directions = []
        self.frames = [0, 0, 0, 0, 0]
        self.difficulty = 1
        self.AYE = 2 + self.difficulty * 3
        self.prev_t, self.prev_b, self.prev_l, self.prev_r = 10000, 10000, 10000, 10000

    def process_draw(self, screen):
        screen.blit(self.image, self.rect)
        self.frame += 1
        if self.is_fear:
            self.fear += 1
        if self.fear > self.max_fear:
            self.is_fear = False
            self.fear = 0
            self.speed = 1

    def set_difficulty(self, diff):
        self.difficulty = diff

    def movement_logic(self, field, player):
        if self.rect.x % 48 == 4 and self.rect.y % 48 == 4:
            if self.is_fear:
                curr_x, curr_y, self.speed, self.status = 0, 1008, 2, 1
            else:
                curr_x, curr_y = player.rect.x, player.rect.y
                if curr_x in range(self.rect.x - self.AYE * 48 - 4, self.rect.x + self.AYE * 48 + 44) and \
                        curr_y in range(self.rect.y - self.AYE * 48 - 4, self.rect.y + self.AYE * 48 + 44):
                    self.status = 1
                else:
                    self.status = 0
            if self.status == 0:
                self.directions = []
                if field[(self.rect.y - 5) // 48][self.rect.x // 48] == "0" and \
                        field[(self.rect.y - 5) // 48][(self.rect.x + 40) // 48] == "0":
                    self.directions.append(0)
                if field[(self.rect.y + 45) // 48][self.rect.x // 48] == "0" and \
                        field[(self.rect.y + 45) // 48][(self.rect.x + 40) // 48] == "0":
                    self.directions.append(1)
                if field[self.rect.y // 48][(self.rect.x - 5) // 48] == "0" and \
                        field[(self.rect.y + 40) // 48][(self.rect.x - 5) // 48] == "0":
                    self.directions.append(2)
                if field[self.rect.y // 48][(self.rect.x + 45) // 48] == "0" and \
                        field[(self.rect.y + 40) // 48][(self.rect.x + 45) // 48] == "0":
                    self.directions.append(3)

                if self.rect.x - 5 < 0:
                    self.rect.x = 48 * 15 + 4
                elif self.rect.x + 45 > 768:
                    self.rect.x = 4
                else:
                    self.direction = choice(self.directions)

                if self.prev_direction == 0 and self.direction == 1:
                    del self.directions[self.directions.index(1)]
                    self.direction = choice(self.directions)
                if self.prev_direction == 1 and self.direction == 0:
                    del self.directions[self.directions.index(0)]
                    self.direction = choice(self.directions)
                if self.prev_direction == 2 and self.direction == 3:
                    del self.directions[self.directions.index(3)]
                    self.direction = choice(self.directions)
                if self.prev_direction == 3 and self.direction == 2:
                    del self.directions[self.directions.index(2)]
                    self.direction = choice(self.directions)
            if self.status == 1:
                if self.rect.x - 5 < 0:
                    self.rect.x = 48 * 15 + 4
                elif self.rect.x + 45 > 768:
                    self.rect.x = 4
                else:
                    self.distances = [10000, 10000, 10000, 10000]
                    if field[(self.rect.y - 5) // 48][self.rect.x // 48] == "0" and \
                            field[(self.rect.y - 5) // 48][(self.rect.x + 40) // 48] == "0":
                        self.distances[0] = math.sqrt((curr_x - self.rect.x) ** 2 + (curr_y - (self.rect.y - 1)) ** 2)
                    if field[(self.rect.y + 45) // 48][self.rect.x // 48] == "0" and \
                            field[(self.rect.y + 45) // 48][(self.rect.x + 40) // 48] == "0":
                        self.distances[1] = math.sqrt((curr_x - self.rect.x) ** 2 + (curr_y - (self.rect.y + 1)) ** 2)
                    if field[self.rect.y // 48][(self.rect.x - 5) // 48] == "0" and \
                            field[(self.rect.y + 40) // 48][(self.rect.x - 5) // 48] == "0":
                        self.distances[2] = math.sqrt((curr_x - (self.rect.x - 1)) ** 2 + (curr_y - self.rect.y) ** 2)
                    if field[self.rect.y // 48][(self.rect.x + 45) // 48] == "0" and \
                            field[(self.rect.y + 40) // 48][(self.rect.x + 45) // 48] == "0":
                        self.distances[3] = math.sqrt((curr_x - (self.rect.x + 1)) ** 2 + (curr_y - self.rect.y) ** 2)
                    self.direction = self.distances.index(min(self.distances))
                    if self.prev_direction == 0 and self.direction == 1:
                        self.distances[self.direction] = 10000
                    if self.prev_direction == 1 and self.direction == 0:
                        self.distances[self.direction] = 10000
                    if self.prev_direction == 2 and self.direction == 3:
                        self.distances[self.direction] = 10000
                    if self.prev_direction == 3 and self.direction == 2:
                        self.distances[self.direction] = 10000
                    self.direction = self.distances.index(min(self.distances))

            if self.direction == 0:
                self.motion[0] = 0
                self.motion[1] = -self.speed
            elif self.direction == 1:
                self.motion[0] = 0
                self.motion[1] = self.speed
            elif self.direction == 2:
                self.motion[0] = -self.speed
                self.motion[1] = 0
            elif self.direction == 3:
                self.motion[0] = self.speed
                self.motion[1] = 0

            self.prev_direction = self.direction

    def process_logic(self):
        self.rect.x += self.motion[0]
        self.rect.y += self.motion[1]

    def animation(self):
        if self.rip:
            self.my_rip_timer += 1
        if self.my_rip_timer > self.max_rip:
            self.rip = False
            self.my_rip_timer = 0
            self.is_fear = False
            self.speed = 1
        if self.is_fear:
            if self.direction == self.prev_direction and self.frame >= self.maxFrames:
                self.frame = 0
                self.frames[4] = (self.frames[4] + 1) % 2
            self.image = self.images_fear[self.frames[4]]
        else:
            if self.direction == 0:
                if self.direction != self.prev_direction:
                    self.frames[0] = 0
                if self.direction == self.prev_direction and self.frame >= self.maxFrames:
                    self.frame = 0
                    self.frames[0] = (self.frames[0] + 1) % 2
                self.image = self.images_top[self.frames[0]]
            if self.direction == 1:
                if self.direction != self.prev_direction:
                    self.frames[1] = 0
                if self.direction == self.prev_direction and self.frame >= self.maxFrames:
                    self.frame = 0
                    self.frames[1] = (self.frames[1] + 1) % 2
                self.image = self.images_bot[self.frames[1]]
            if self.direction == 2:
                if self.direction != self.prev_direction:
                    self.frames[2] = 0
                if self.direction == self.prev_direction and self.frame >= self.maxFrames:
                    self.frame = 0
                    self.frames[2] = (self.frames[2] + 1) % 2
                self.image = self.images_lef[self.frames[2]]
            if self.direction == 3:
                if self.direction != self.prev_direction:
                    self.frames[3] = 0
                if self.direction == self.prev_direction and self.frame >= self.maxFrames:
                    self.frame = 0
                    self.frames[3] = (self.frames[3] + 1) % 2
                self.image = self.images_rig[self.frames[3]]
