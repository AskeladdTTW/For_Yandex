import pygame
import operator
import collections
import sys

White = 255, 255, 255
Black = 0, 0, 0
Red = 255, 0, 0
WIDTH = 1200
HEIGHT = 1000


class LeaderBoard:
    names = {}

    def __init__(self):
        with open('LeaderBoard.txt') as f:
            for line in f:
                nam, sc = line.split()
                sc = int(sc)
                self.names[nam] = sc

    def update(self, pl_name, pl_score):
        self.names[pl_name] = pl_score
        self.names = sorted(self.names.items(), key=operator.itemgetter(1))
        self.names = collections.OrderedDict(self.names)
        f = open('LeaderBoard.txt', 'a')
        f.write(pl_name + " " + str(pl_score) + "\n")
        f.close()

    def paint(self, screen):
        screen.fill(Black)
        text1 = 'Leaderboard:'
        font_t = pygame.font.SysFont('Comic Sans MS', 70, True)
        font_n = pygame.font.SysFont('Comic Sans MS', 30, True)
        title = font_t.render(text1, False, White)
        texts = [key for key in self.names]
        values = [self.names[key] for key in self.names]
        texts, values = texts[::-1], values[::-1]
        screen.blit(title, (50, 100))
        merge = 150
        for i in range(len(texts)):
            name = font_n.render(str(i + 1) + ". " + texts[i], False, White)
            sc = font_n.render(str(values[i]), False, White)
            screen.blit(name, (50, HEIGHT // 2 - 150 - merge))
            screen.blit(sc, (400, HEIGHT // 2 - 150 - merge))
            merge -= 30

    def paint_top_5(self, screen):
        text1 = 'Top 3'
        font_t = pygame.font.SysFont('Comic Sans MS', 70, True)
        font_n = pygame.font.SysFont('Comic Sans MS', 50, True)
        title = font_t.render(text1, False, Red)
        texts = [key for key in self.names]
        values = [self.names[key] for key in self.names]
        texts, values = texts[::-1], values[::-1]
        screen.blit(title, (300, 130))
        merge = 200
        if len(texts) < 3:
            rn = len(texts)
        else:
            rn = 3
        for i in range(rn):
            name = font_n.render(str(i + 1) + ". " + texts[i], False, Red)
            sc = font_n.render(str(values[i]), False, Red)
            screen.blit(name, (200, HEIGHT // 2 - 100 - merge))
            screen.blit(sc, (500, HEIGHT // 2 - 100 - merge))
            merge -= 50

    def show(self, screen):
        return_btn_x, return_btn_y = 700, 200
        return_btn_img = pygame.image.load('images/return_btn.png')
        return_to_menu = False
        while not return_to_menu:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if return_btn_y <= event.pos[1] <= return_btn_y + 22 and return_btn_x <= event.pos[
                        0] <= return_btn_x + 50:
                        return_to_menu = True
            self.paint(screen)
            screen.blit(return_btn_img, (return_btn_x, return_btn_y))
            pygame.display.flip()
            pygame.time.wait(10)
