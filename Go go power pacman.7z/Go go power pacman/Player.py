import pygame
from sounds import dots_eating_sound, eating_fruit_sound, dying_sound, eating_ghost_sound

black = 0, 0, 0


class Player:
    images = [pygame.image.load('images/pc.png'), pygame.image.load('images/pc_down_eat.png'),
              pygame.image.load('images/pc_down_eat_f.png'), pygame.image.load('images/pc_up_eat.png'),
              pygame.image.load('images/pc_up_eat_f.png'), pygame.image.load('images/pc_left_eat.png'),
              pygame.image.load('images/pc_left_eat_f.png'), pygame.image.load('images/pc_right_eat.png'),
              pygame.image.load('images/pc_right_eat_f.png')]
    images_die_up = [pygame.image.load('images/die/pc_die_up_1.png'),
                     pygame.image.load('images/die/pc_die_up_2.png'),
                     pygame.image.load('images/die/pc_die_up_3.png'),
                     pygame.image.load('images/die/pc_die_up_1.png'),
                     pygame.image.load('images/die/pc_die_up_4.png'),
                     pygame.image.load('images/die/pc_die_up_5.png'),
                     pygame.image.load('images/die/pc_die_up_6.png'),
                     pygame.image.load('images/die/pc_die_up_7.png'),
                     pygame.image.load('images/die/pc_die_up_8.png'),
                     pygame.image.load('images/die/pc_die_up_9.png'),
                     pygame.image.load('images/die/pc_die_up_10.png'),
                     pygame.image.load('images/die/pc_die_up_11.png')]
    images_die_down = [pygame.image.load('images/die/pc_die_down_1.png'),
                       pygame.image.load('images/die/pc_die_down_2.png'),
                       pygame.image.load('images/die/pc_die_down_3.png'),
                       pygame.image.load('images/die/pc_die_down_1.png'),
                       pygame.image.load('images/die/pc_die_down_4.png'),
                       pygame.image.load('images/die/pc_die_down_5.png'),
                       pygame.image.load('images/die/pc_die_down_6.png'),
                       pygame.image.load('images/die/pc_die_down_7.png'),
                       pygame.image.load('images/die/pc_die_down_8.png'),
                       pygame.image.load('images/die/pc_die_down_9.png'),
                       pygame.image.load('images/die/pc_die_down_10.png'),
                       pygame.image.load('images/die/pc_die_down_11.png')]
    images_die_left = [pygame.image.load('images/die/pc_die_left_1.png'),
                       pygame.image.load('images/die/pc_die_left_2.png'),
                       pygame.image.load('images/die/pc_die_left_3.png'),
                       pygame.image.load('images/die/pc_die_left_1.png'),
                       pygame.image.load('images/die/pc_die_left_4.png'),
                       pygame.image.load('images/die/pc_die_left_5.png'),
                       pygame.image.load('images/die/pc_die_left_6.png'),
                       pygame.image.load('images/die/pc_die_left_7.png'),
                       pygame.image.load('images/die/pc_die_left_8.png'),
                       pygame.image.load('images/die/pc_die_left_9.png'),
                       pygame.image.load('images/die/pc_die_left_10.png'),
                       pygame.image.load('images/die/pc_die_left_11.png')]
    images_die_right = [pygame.image.load('images/die/pc_die_right_1.png'),
                        pygame.image.load('images/die/pc_die_right_2.png'),
                        pygame.image.load('images/die/pc_die_right_3.png'),
                        pygame.image.load('images/die/pc_die_right_1.png'),
                        pygame.image.load('images/die/pc_die_right_4.png'),
                        pygame.image.load('images/die/pc_die_right_5.png'),
                        pygame.image.load('images/die/pc_die_right_6.png'),
                        pygame.image.load('images/die/pc_die_right_7.png'),
                        pygame.image.load('images/die/pc_die_right_8.png'),
                        pygame.image.load('images/die/pc_die_right_9.png'),
                        pygame.image.load('images/die/pc_die_right_10.png'),
                        pygame.image.load('images/die/pc_die_right_11.png')]
    image = pygame.image.load('images/pc_left_eat.png')

    frames_die = 0  # Счетчик кадров, служит для анимации сметри
    maxFrames_die = 15  # Количество кадров, при которых сменяется фаза анимации смерти(ставиться другая картинка)
    frames = 0  # Счетчик кадров, служит для анимации движения
    maxFrames = 15  # Количество кадров, при которых сменяется фаза анимации движения(ставиться другая картинка)

    phase = 2  # Фаза анимации, фактически индекс картинки, которая сейчас включеня в массиве для анимации движения
    phase_die = 3  # Фаза анимации, фактически индекс картинки, которая сейчас включеня в массиве для анимации смерти
    angle = 3  # Угол поворота картинки, их всего 4(вверх, вниз, вправо, влево)

    speed = 2  # Скорость движения
    motion = [0.0, 0.0]  # Вектор движения
    direction = [0, 0]  # Вектор направления(служит для проверки клеток в переди пакмана)
    move = False  # Может ли пакман двигаться(служит для анимации)
    # Когда пакман  уперается в стену, анимация останавливается
    lock = False  # Может ли пакман ходить(когда пакман телепортируется, он не должен управляться игроком)
    edge = 0  # На каком краю телепорта находиться пакман
    # (всего три значения -1 - левый край телепорта, 0 - он не находиться в телепорте, 1 - правый край телепорта)

    cell_x = 0  # Клетка по Х, в которой находиться пакман
    cell_y = 0  # Клетка по Y, в которой находться пакман

    can_you_touch_me = True  # Может ли пакмана трогать приведения(служит для правльного счёта HP)

    HP = 1  # Количество здоровья пакмана
    BERRIES = 0  # Количество ягод у пакмана

    def __init__(self, x: int = None, y: int = None, sp: float = None):
        self.rect = self.images[0].get_rect()
        if sp:
            self.speed = sp
        if x is None:
            x = 0
            y = 0
        self.rect.x = x
        self.rect.y = y
        self.who_is_daddy_now = False
        self.center = [x + self.rect.width // 2, y + self.rect.height // 2]  # Высчитывания центра

    def collides_with(self, obj):  # Проверка столкновения с объектом obj
        # (если столкнулся, то вызываем соответствующую функцию)
        return pygame.sprite.collide_rect(self, obj)

    def collides_with_ghost(self):  # Столкновение с приведением
        if self.HP > 0:
            self.HP -= 1
            self.can_you_touch_me = False  # Если пакман столкнулся с приведением,
            # то до рестарта они не могут трогать пакмана
            print(self.HP)
        else:
            print("You lose", self.HP)

    def collides_with_fruit(self):  # Столкновение с фруктом
        if self.BERRIES < 3:
            self.BERRIES += 1
        eating_fruit_sound()

    def process_draw(self, screen):  # Отображение пакмана
        self.image = pygame.transform.scale(self.image, (35, 35))  # Изменение размера
        self.center = [self.rect.x + self.rect.width // 2, self.rect.y + self.rect.height // 2]
        # Если размер изменился, то надо заново центр высчитывать
        screen.blit(self.image, self.rect)
        if self.can_you_touch_me:  # Эти
            self.frames += 1  # Строчки
        else:  # Нужны для
            self.frames_die += 1  # Анимации

    def animation_delay(self):  # Фукция для того, чтобы анимация смерти полностью проиграла
        if self.phase_die == len(self.images_die_up):
            return True
        else:
            return False

    def process_animation_die(self):  # Обычная анимация
        if self.frames_die >= self.maxFrames_die \
                and self.phase_die != len(self.images_die_up) \
                and self.angle == 1:
            self.image = self.images_die_up[self.phase_die]  # Изменение картинки в соотвтствии с фазой
            self.frames_die = 0  # Обнуление количества кадров
            self.phase_die += 1  # Ставим следующую фазу(следующую картинку)
        if self.frames_die >= self.maxFrames_die \
                and self.phase_die != len(self.images_die_down) \
                and self.angle == 2:
            self.image = self.images_die_down[self.phase_die]  # Изменение картинки в соотвтствии с фазой
            self.frames_die = 0  # Обнуление количества кадров
            self.phase_die += 1  # Ставим следующую фазу(следующую картинку)
        if self.frames_die >= self.maxFrames_die \
                and self.phase_die != len(self.images_die_left) \
                and self.angle == 3:
            self.image = self.images_die_left[self.phase_die]  # Изменение картинки в соотвтствии с фазой
            self.frames_die = 0  # Обнуление количества кадров
            self.phase_die += 1  # Ставим следующую фазу(следующую картинку)
        if self.frames_die >= self.maxFrames_die \
                and self.phase_die != len(self.images_die_right) \
                and self.angle == 4:
            self.image = self.images_die_right[self.phase_die]  # Изменение картинки в соотвтствии с фазой
            self.frames_die = 0  # Обнуление количества кадров
            self.phase_die += 1  # Ставим следующую фазу(следующую картинку)

    def process_animation_move(self):  # Это тоже обычная анимация
        if self.move:  # Если включена анимация
            if (self.frames >= self.maxFrames) \
                    and (self.angle == 1) \
                    and (self.phase == 3):
                self.image = self.images[4]  # Установка картинки в соответствии с фазой
                self.frames = 0  # Обнуление количества кадров
                self.phase = 1  # Установка следующей фазы
            elif (self.frames >= self.maxFrames) \
                    and (self.angle == 2) \
                    and (self.phase == 3):
                self.image = self.images[2]  # Установка картинки в соответствии с фазой
                self.frames = 0  # Обнуление количества кадров
                self.phase = 1  # Установка следующей фазы
            elif (self.frames >= self.maxFrames) \
                    and (self.angle == 3) \
                    and (self.phase == 3):
                self.image = self.images[6]  # Установка картинки в соответствии с фазой
                self.frames = 0  # Обнуление количества кадров
                self.phase = 1  # Установка следующей фазы
            elif (self.frames >= self.maxFrames) \
                    and (self.angle == 4) \
                    and (self.phase == 3):
                self.image = self.images[8]  # Установка картинки в соответствии с фазой
                self.frames = 0  # Обнуление количества кадров
                self.phase = 1  # Установка следующей фазы

            elif (self.frames >= self.maxFrames) \
                    and (self.angle == 1) \
                    and (self.phase == 1):
                self.image = self.images[0]  # Установка картинки в соответствии с фазой
                self.frames = 0  # Обнуление количества кадров
                self.phase = 2  # Установка следующей фазы
            elif (self.frames >= self.maxFrames) \
                    and (self.angle == 2) \
                    and (self.phase == 1):
                self.image = self.images[0]  # Установка картинки в соответствии с фазой
                self.frames = 0  # Обнуление количества кадров
                self.phase = 2  # Установка следующей фазы
            elif (self.frames >= self.maxFrames) \
                    and (self.angle == 3) \
                    and (self.phase == 1):
                self.image = self.images[0]  # Установка картинки в соответствии с фазой
                self.frames = 0  # Обнуление количества кадров
                self.phase = 2  # Установка следующей фазы
            elif (self.frames >= self.maxFrames) \
                    and (self.angle == 4) \
                    and (self.phase == 1):
                self.image = self.images[0]  # Установка картинки в соответствии с фазой
                self.frames = 0  # Обнуление количества кадров
                self.phase = 2  # Установка следующей фазы

            elif (self.frames >= self.maxFrames) \
                    and (self.angle == 1) \
                    and (self.phase == 2):
                self.image = self.images[3]  # Установка картинки в соответствии с фазой
                self.frames = 0  # Обнуление количества кадров
                self.phase = 3  # Установка следующей фазы
            elif (self.frames >= self.maxFrames) \
                    and (self.angle == 2) \
                    and (self.phase == 2):
                self.image = self.images[1]  # Установка картинки в соответствии с фазой
                self.frames = 0  # Обнуление количества кадров
                self.phase = 3  # Установка следующей фазы
            elif (self.frames >= self.maxFrames) \
                    and (self.angle == 3) \
                    and (self.phase == 2):
                self.image = self.images[5]  # Установка картинки в соответствии с фазой
                self.frames = 0  # Обнуление количества кадров
                self.phase = 3  # Установка следующей фазы
            elif (self.frames >= self.maxFrames) \
                    and (self.angle == 4) \
                    and (self.phase == 2):
                self.image = self.images[7]  # Установка картинки в соответствии с фазой
                self.frames = 0  # Обнуление количества кадров
                self.phase = 3  # Установка следующей фазы

    def process_keyboard(self, event, data, cell):  # Обработка клавиатуры
        if self.check_in_cell(cell):  # Проверка, что центр пакмана совпадает с
            # центральным квадратом клетки в которой он находится
            if (event.key == pygame.K_UP or event.key == pygame.K_w) and self.can_you_touch_me \
                    and self.check_cell_by_cords(data, 0, -1) and self.lock is False:
                self.motion[0] = 0.0  # Установка движения по другой координате в 0
                self.motion[1] = -self.speed  # Установка движения по заданной координате
                self.direction[0] = 0  # Смена направления движения
                self.direction[1] = -1  # Смена направления движения
                self.angle = 1  # Изменения угла(вверх)
                self.frames = self.maxFrames  # Надо, чтобы обновлялась анимация после изменения угла
                self.rect.y = cell.y + 6  # Коректирование положения пакмана до центра клетки, в которой он сейчас
                self.rect.x = cell.x + 6  # Коректирование положения пакмана до центра клетки, в которой он сейчас
            elif (event.key == pygame.K_DOWN or event.key == pygame.K_s) and self.can_you_touch_me \
                    and self.check_cell_by_cords(data, 0, 1) and self.lock is False:
                self.motion[0] = 0.0  # Установка движения по другой координате в 0
                self.motion[1] = self.speed  # Установка движения по заданной координате
                self.direction[0] = 0  # Смена направления движения
                self.direction[1] = 1  # Смена направления движения
                self.angle = 2  # Изменения угла(вниз)
                self.frames = self.maxFrames  # Надо, чтобы обновлялась анимация после изменения угла
                self.rect.y = cell.y + 6  # Коректирование положения пакмана до центра клетки, в которой он сейчас
                self.rect.x = cell.x + 6  # Коректирование положения пакмана до центра клетки, в которой он сейчас
            elif (event.key == pygame.K_LEFT or event.key == pygame.K_a) and self.can_you_touch_me \
                    and self.check_cell_by_cords(data, -1, 0) and self.lock is False:
                self.motion[0] = -self.speed  # Установка движения по заданной координате
                self.motion[1] = 0.0  # Установка движения по другой координате в 0
                self.direction[0] = -1  # Смена направления движения
                self.direction[1] = 0  # Смена направления движения
                self.angle = 3  # Изменения угла(влево)
                self.frames = self.maxFrames  # Надо, чтобы обновлялась анимация после изменения угла
                self.rect.y = cell.y + 6  # Коректирование положения пакмана до центра клетки, в которой он сейчас
                self.rect.x = cell.x + 6  # Коректирование положения пакмана до центра клетки, в которой он сейчас
            elif (event.key == pygame.K_RIGHT or event.key == pygame.K_d) and self.can_you_touch_me \
                    and self.check_cell_by_cords(data, 1, 0) and self.lock is False:
                self.motion[0] = self.speed  # Установка движения по заданной координате
                self.motion[1] = 0.0  # Установка движения по другой координате в 0
                self.direction[0] = 1  # Смена направления движения
                self.direction[1] = 0  # Смена направления движения
                self.angle = 4  # Изменения угла(вправо)
                self.frames = self.maxFrames  # Надо, чтобы обновлялась анимация после изменения угла
                self.rect.y = cell.y + 6  # Коректирование положения пакмана до центра клетки, в которой он сейчас
                self.rect.x = cell.x + 6  # Коректирование положения пакмана до центра клетки, в которой он сейчас

    def check_in_cell(self, cell):  # Функция для проверки, что центр пакмана совпадает с
        # центральным квадратом клетки в которой он находится
        return cell.rect2.collidepoint(self.center[0], self.center[1])

    def check_cell(self, data):  # Функция для проверки, что пере пакманом пустая клетка, а не стена
        return data[self.cell_y + self.direction[1]][self.cell_x + self.direction[0]] == '0'

    def check_score(self, cell, screen, count_score, font):
        if cell.isDot:
            dots_eating_sound()
            pygame.draw.rect(screen, black, cell.dot_Rect, cell.line_width)
            count_score += 10
            cell.isDot = False
        if cell.isSuper_Dot:
            dots_eating_sound()
            pygame.draw.circle(screen, black, cell.centre, 5, cell.line_width)
            cell.isSuper_Dot = False
            self.who_is_daddy_now = True
            count_score += 50

        font_t = pygame.font.SysFont('Comic Sans MS', 70, True)
        score_info = "Score: " + str(count_score)
        title = font_t.render(score_info, False, (255, 255, 255))
        screen.blit(title, (500 - title.get_width() // 2, 0))
        # 700 - text.get_width() // 2, 55 - text.get_height() // 2)
        p = [cell.isDot, count_score]
        return p

    def check_cell_by_cords(self, data, cell_x, cell_y):  # Функция проверки, что через произволиные числа
        # в направлении движения пакманом пусто, а не стена
        return data[self.cell_y + cell_y][self.cell_x + cell_x] == '0'

    def process_logic(self, data, cell, field):  # Основная механика движения
        if self.HP != 0:
            if self.check_in_cell(field[10][0]) and self.direction[0] != 1 and self.edge != -1:  # Проверка,
                # можно ли зайти в телерорт
                self.lock = True  # Заблокировать управление
                self.edge = -1  # Смена края телепорта, на котором находиться пакман
            elif self.edge == -1 and self.direction[0] != 1 and self.rect.x <= -cell.cell_size:  # Проверка что, пакман
                # зашел за край экрана и дошел до определённой точки
                self.rect.x = cell.cell_size * 16  # Телепорт на координаты другого телепорта(за экран)
                self.edge = 0  # Говорим, что пакман какбы уже вышел из телепорта
                self.lock = False  # Разблокировать управление
            elif self.edge == -1:  # Проверка, что пакмна находиться на телепорте слева
                self.rect.x -= self.speed  # Двигаем пакмана влево на значение скорости

            elif self.check_in_cell(field[10][15]) and self.direction[0] != -1 and self.edge != 1:  # Проверка,
                # можно ли зайти в телерорт
                self.lock = True  # Заблокировать управление
                self.edge = 1  # Смена края телепорта, на котором находиться пакман
            elif self.edge == 1 and self.direction[0] != -1 and self.rect.x >= 768 + cell.cell_size:  # Проверка что,
                # пакман зашел за край экрана и дошел до определённой точки
                self.rect.x = -cell.cell_size  # Телепорт на координаты другого телепорта(за экран)
                self.edge = 0  # Говорим, что пакман какбы уже вышел из телепорта
                self.lock = False  # Разблокировать управление
            elif self.edge == 1:  # Проверка, что пакмна находиться на телепорте справа
                self.rect.x += self.speed  # Двигаем пакмана вправо на значение скорости

            elif (self.check_cell(data) or (self.motion[0] != 0 and self.center[0] != cell.centre[0]) or \
                  (self.motion[1] != 0 and self.center[1] != cell.centre[1])) and self.can_you_touch_me:
                # Проверка на много что, но кратко на то, чтобы перед пакманом ничего не было и он мог идти
                # В направление motion и direction
                self.move = True  # Анимация движения идёт
                self.rect.x += self.motion[0]  # Движения по X
                self.rect.y += self.motion[1]  # Движение по Y
            else:
                self.move = False  # Анимация движения приостановлена
