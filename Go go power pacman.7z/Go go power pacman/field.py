import pygame
import sys

from Cell import Cell

size = width, height = 768, 1008
black = 0, 0, 0
blue = 0, 0, 255

my_field = []


def make_field():
    # screen.fill(black)
    screen = pygame.display.set_mode(size)

    f = open('field.txt', 'r')
    data = f.readlines()
    for i in range(len(data)):
        for j in range(len(data[i])):
            if data[i][j] == '*':
                a = Cell(blue, j * 48, i * 48, 48, 5)
                my_field.append(a)
    for i in my_field:
        i.process_draw(screen)
