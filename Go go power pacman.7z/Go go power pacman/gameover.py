import pygame
import sys
import os
from sounds import opening_sound
from LeaderBoardScript import LeaderBoard
from init import *

size = width, height = 768, 1008
black = 0, 0, 0
red = 255, 0, 0


class Button:
    def __init__(self, x, y, width, height, text, t_size, t_color, x_gap, y_gap):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.button_color = (255, 255, 255)
        self.text_size = t_size
        self.x_gap = x_gap
        self.y_gap = y_gap
        self.text = pygame.font.SysFont('Comic Sans MS', t_size).render(text, True, t_color)

    def draw(self, screen):
        pygame.draw.rect(screen, self.button_color, [self.x, self.y, self.width, self.height])
        screen.blit(self.text, (self.x + self.x_gap, self.y + self.y_gap))

    def is_pressed(self, mouse):
        if self.x <= mouse[0] <= self.x + self.width and self.y <= mouse[1] <= self.y + self.height:
            self.button_color = (255, 255, 0)
            return True
        else:
            self.button_color = (255, 255, 255)


def draw_title(screen):
    # logo1 = pygame.image.load('images/menu/Pacman_logo.png')
    logo2 = pygame.image.load('images/menu/game_over_title.png')
    x = 550
    # logo1 = pygame.transform.scale(logo1, (x, int(x / 4)))
    # screen.blit(logo1, [width / 2 - 280, 100, 150, 150])
    x = 550
    logo2 = pygame.transform.scale(logo2, (x, int(x / 4)))
    screen.blit(logo2, [width / 2 - 280, 20, 150, 150])


def draw_title_won(screen):
    logo = pygame.image.load('images/menu/you_won.png')
    x = 550
    logo = pygame.transform.scale(logo, (x + 200, int(x / 4)))
    screen.blit(logo, [width / 2 - 380, 20, 150, 150])


def draw_background(screen):
    logo = pygame.image.load('images/menu/Power_rangers.jpeg')
    logo = pygame.transform.scale(logo, (width, int(1366 / 9 * 8)))
    screen.blit(logo, [0, 0, 150, 150])


def game_over(count_score, is_lose):
    pygame.init()
    opening_sound()
    screen = pygame.display.set_mode(size)
    stop = False
    x = 250
    back_button = Button(width / 2 - x, 900, 550, 60, "BACK TO MENU", 100, black, 10, 0)
    font_1 = pygame.font.SysFont('Comic Sans MS', 50, True)
    font_2 = pygame.font.SysFont('Comic Sans MS', 40, True)

    pl_name = ''
    name_text = 'Enter your name'
    text_1 = font_1.render(name_text, 1, red)

    pygame.display.update()
    enter_name_flag = True

    while not stop:
        mouse = pygame.mouse.get_pos()
        keys = pygame.key.get_pressed()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            if event.type == pygame.KEYDOWN and enter_name_flag:
                if event.key == pygame.K_RETURN:
                    leaderboard.update(pl_name, count_score)
                    enter_name_flag = False
                elif event.key == pygame.K_SPACE:
                    pl_name += ' '
                key = pygame.key.name(event.key)

                if len(key) == 1:
                    if keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]:
                        pl_name += key.upper()
                    else:
                        pl_name += key
                elif key == "backspace":
                    pl_name = pl_name[:len(pl_name) - 1]

                pygame.display.update()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if back_button.is_pressed(mouse):
                    return

        if not pygame.mixer.music.get_busy():
            opening_sound()
        screen.fill(black)

        back_button.is_pressed(mouse)

        draw_background(screen)
        back_button.draw(screen)
        if is_lose:
            draw_title(screen)
        else:
            draw_title_won(screen)
        if enter_name_flag:
            screen.blit(text_1, (width // 2 - len(name_text) * 10, 140))
            text = font_2.render(pl_name, 1, red)
            screen.blit(text, (width // 2 - len(pl_name) * 8, 200))
        else:
            leaderboard.paint_top_5(screen)
        pygame.display.update()
        pygame.display.flip()
        pygame.time.wait(10)


if __name__ == '__main__':
    game_over(100)
