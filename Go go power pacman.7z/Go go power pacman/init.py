import pygame
import random

from Player import Player  # Импорт класса пакмана
from Cell import Cell
from Ghost import Ghost
from Ghost_2 import Ghost2
from Ghost_3 import Ghost3
from Ghost_4 import Ghost4
from LeaderBoardScript import LeaderBoard

size = width, height = 768, 1008
black = 0, 0, 0
blue = 0, 0, 255

start_for_player = [48 * 3 + 4, 48 * 4 + 4]  # Начальные координаты пакмана(с учётом размеров клеток)
start_for_ghost_1 = [48 * 9 + 4, 48 * 7 + 4]
start_for_ghost_2 = [4 + 48 * 10, 48 * 10 + 4]
start_for_ghost_3 = [4 + 48 * 14, 48 * 10 + 4]
start_for_ghost_4 = [4 + 48 * 14, 48 * 10 + 4]

player = Player(start_for_player[0], start_for_player[1])  # Спавн пакмана по заданным координатам

ghost_1 = Ghost(start_for_ghost_1[0], start_for_ghost_1[1])
ghost_2 = Ghost2(start_for_ghost_2[0], start_for_ghost_2[1])
ghost_3 = Ghost3(start_for_ghost_3[0], start_for_ghost_3[1])
ghost_4 = Ghost4(start_for_ghost_4[0], start_for_ghost_4[1])

clock = pygame.time.Clock()

leaderboard = LeaderBoard()

difficulty = 1

field = []
f = open('field.txt', 'r')
data = f.readlines()
s = 0
for i in range(len(data)):
    temp = []
    for j in range(len(data[i])):
        if data[i][j] == '1':
            a = Cell((0, 0, 255), j * 48, i * 48, 48, 0, 1)
            temp.append(a)
        elif i != 0:
            if s <= 4 and random.randrange(0, 25) == 10 and j * 48 != start_for_player[1] and i * 48 != \
                    start_for_player[0]:
                a = Cell((0, 0, 255), j * 48, i * 48, 48, 0, 2)
                s += 1
                temp.append(a)
            elif j * 48 != start_for_player[1] and i * 48 != start_for_player[0]:
                a = Cell((0, 0, 255), j * 48, i * 48, 48, 0, 0)
                temp.append(a)
    field.append(temp)


def restart_all_game():
    global player
    player.HP = 1

    global field, data
    field = []
    f = open('field.txt', 'r')
    data = f.readlines()
    s = 0
    for i in range(len(data)):
        temp = []
        for j in range(len(data[i])):
            if data[i][j] == '1':
                a = Cell((0, 0, 255), j * 48, i * 48, 48, 0, 1)
                temp.append(a)
            elif i != 0:
                if s <= 4 and random.randrange(0, 25) == 10 and j * 48 != start_for_player[0] and i * 48 != \
                        start_for_player[1]:
                    a = Cell((0, 0, 255), j * 48, i * 48, 48, 0, 2)
                    s += 1
                    temp.append(a)
                else:
                    a = Cell((0, 0, 255), j * 48, i * 48, 48, 0, 0)
                    temp.append(a)
        field.append(temp)

    return field
