import pygame
import sys
import os
import gameover
from sounds import opening_sound
from settings import settings
from LeaderBoardScript import LeaderBoard
from run import game
from init import *

GAME_FOLDER = os.path.dirname(__file__)

size = width, height = 768, 1008
black = 0, 0, 0
blue = 0, 0, 255
clock = pygame.time.Clock()


class Button:
    def __init__(self, x, y, width, height, text, t_size, t_color, x_gap, y_gap):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.button_color = (255, 255, 255)
        self.text_size = t_size
        self.x_gap = x_gap
        self.y_gap = y_gap
        self.text = pygame.font.SysFont('Comic Sans MS', t_size).render(text, True, t_color)

    def draw(self, screen):
        pygame.draw.rect(screen, self.button_color, [self.x, self.y, self.width, self.height])
        screen.blit(self.text, (self.x + self.x_gap, self.y + self.y_gap))

    def is_pressed(self, mouse):
        if self.x <= mouse[0] <= self.x + self.width and self.y <= mouse[1] <= self.y + self.height:
            self.button_color = (255, 255, 0)
            return True
        else:
            self.button_color = (255, 255, 255)


def draw_title(screen):
    logo = pygame.image.load('images/menu/Pacman_logo.png')
    x = 550
    logo = pygame.transform.scale(logo, (x, int(x / 4)))
    screen.blit(logo, [width / 2 - 280, 100, 150, 150])


def draw_background(screen):
    logo = pygame.image.load('images/menu/Power_rangers.jpeg')
    logo = pygame.transform.scale(logo, (width, int(1366 / 9 * 8)))
    screen.blit(logo, [0, 0, 150, 150])


def main():
    pygame.init()
    opening_sound()
    screen = pygame.display.set_mode(size)
    game_over = False

    x = 225
    start_button = Button(width / 2 - x, 350, 450, 100, "Start", 100, black, 140, 15)
    settings_button = Button(width / 2 - x, 500, 450, 100, "Settings", 100, black, 70, 15)
    leaderboard_button = Button(width / 2 - x, 650, 450, 100, "Leaderboard", 100, black, 5, 15)
    exit_button = Button(width / 2 - x, 800, 450, 100, "Exit", 100, black, 150, 15)

    while not game_over:
        mouse = pygame.mouse.get_pos()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_over = True
            if event.type == pygame.MOUSEBUTTONDOWN:
                if start_button.is_pressed(mouse):
                    pygame.mixer.music.stop()
                    #restart_all_game()
                    is_lose, count_score = game()
                    if is_lose:
                        gameover.game_over(count_score, True)
                    else:
                        gameover.game_over(count_score, False)
                if settings_button.is_pressed(mouse):
                    settings()
                if leaderboard_button.is_pressed(mouse):
                    leaderboard.show(screen)
                if exit_button.is_pressed(mouse):
                    sys.exit()
        if not pygame.mixer.music.get_busy():
            opening_sound()
        screen.fill(black)

        start_button.is_pressed(mouse)
        settings_button.is_pressed(mouse)
        leaderboard_button.is_pressed(mouse)
        exit_button.is_pressed(mouse)

        draw_background(screen)
        start_button.draw(screen)
        settings_button.draw(screen)
        leaderboard_button.draw(screen)
        exit_button.draw(screen)
        draw_title(screen)

        pygame.display.update()
        pygame.display.flip()
        clock.tick(60)
    sys.exit()


if __name__ == '__main__':
    main()
