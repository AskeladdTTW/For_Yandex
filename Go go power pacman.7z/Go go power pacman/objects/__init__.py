from .ball import BallObject
from .button import ButtonObject
from .image import ImageObject
from .text import TextObject