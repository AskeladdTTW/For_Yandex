import pygame
import sys

from Fruit import Fruit
from sounds import dying_sound, eating_ghost_sound, go_go_power_rangers_sound

from init import *

fruit = Fruit()


def ghost_default():
    ghost_1.rect.x = start_for_ghost_1[0]
    ghost_1.rect.y = start_for_ghost_1[1]
    ghost_2.rect.x = start_for_ghost_2[0]
    ghost_2.rect.y = start_for_ghost_2[1]
    ghost_3.rect.x = start_for_ghost_3[0]
    ghost_3.rect.y = start_for_ghost_3[1]
    ghost_4.rect.x = start_for_ghost_4[0]
    ghost_4.rect.y = start_for_ghost_4[1]


def pacman_default():  # Респван пакмана
    player.rect.x = start_for_player[0]  # Задание стандартных координат
    player.rect.y = start_for_player[1]  # Задание стандартных координат
    player.phase_die = 3  # Установка фазы анимации в дефолтное состаяние
    player.can_you_touch_me = True  # Установка коллизий с приведениями на вкл
    player.motion[0], player.motion[1] = 0.0, 0.0  # Зануление вектора движения
    player.direction[0], player.direction[1] = 0, 0  # Зануление вектора направления
    player.lock = False  # Установка блокировки клавиатуры в дефолтное состояние
    player.edge = 0  # Установка краая телепорта на положение - не на телепорте
    player.angle = 3  # Установка угла анимации в дефолтное состаяние
    player.phase = 2  # Установка фазы анимации в дефолтное состаяние
    player.frames = 999  # Для скидывания анимации
    player.frames_die = 999  # Для скидывания анимации


def restart():
    global sound_flag
    if player.HP > 0:  # Рестарт, если у пакмана ещё есть жизни
        ghost_default()
        pacman_default()  # Вызов функции респавна пакмана
        sound_flag = 1


count_score = 0
sound_flag = 1


def game():
    pygame.init()
    screen = pygame.display.set_mode(size)
    game_over = False
    global count_score, sound_flag

    count_score = 0
    sound_flag = 1

    go_go_power_rangers_sound()

    field = restart_all_game()

    font = pygame.font.SysFont("comicsansms", 20)

    while not game_over:
        clock.tick(60)

        screen.fill(black)

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                player.process_keyboard(event, data, field[player.cell_y][player.cell_x])  # Управление пакманом
            if event.type == pygame.QUIT:
                game_over = True

        for i in field:
            for j in i:
                j.process_draw(screen)

        if player.who_is_daddy_now:
            ghost_1.is_fear = True
            ghost_2.is_fear = True
            ghost_3.is_fear = True
            ghost_4.is_fear = True
            player.who_is_daddy_now = False

        if count_score >= fruit.ogr:
            fruit.spawn()
            fruit.can_you_eat_me = True
            fruit.ogr += 700

        if player.collides_with(ghost_1) and player.can_you_touch_me:  # Проверка на коллизию с приведением 1
            if ghost_1.is_fear:
                ghost_1.rip = True
                ghost_1.is_fear = False
                count_score += 100
                ghost_1.rect.x = start_for_ghost_1[0]
                ghost_1.rect.y = start_for_ghost_1[1]
                eating_ghost_sound()
            elif not ghost_1.rip:
                player.collides_with_ghost()  # Вызов функции коллизии с приведением

        if player.collides_with(ghost_2) and player.can_you_touch_me:  # Проверка на коллизию с приведением 2
            if ghost_2.is_fear:
                ghost_2.rip = True
                ghost_2.is_fear = False
                count_score += 100
                ghost_2.rect.x = start_for_ghost_2[0]
                ghost_2.rect.y = start_for_ghost_2[1]
                eating_ghost_sound()
            elif not ghost_2.rip:
                player.collides_with_ghost()  # Вызов функции коллизии с приведением

        if player.collides_with(ghost_3) and player.can_you_touch_me:  # Проверка на коллизию с приведением 3
            if ghost_3.is_fear:
                ghost_3.rip = True
                ghost_3.is_fear = False
                count_score += 100
                ghost_3.rect.x = start_for_ghost_3[0]
                ghost_3.rect.y = start_for_ghost_3[1]
                eating_ghost_sound()
            elif not ghost_3.rip:
                player.collides_with_ghost()  # Вызов функции коллизии с приведением

        if player.collides_with(ghost_4) and player.can_you_touch_me:  # Проверка на коллизию с приведением 4
            if ghost_4.is_fear:
                ghost_4.rip = True
                ghost_4.is_fear = False
                count_score += 100
                ghost_4.rect.x = start_for_ghost_4[0]
                ghost_4.rect.y = start_for_ghost_4[1]
                eating_ghost_sound()
            elif not ghost_4.rip:
                player.collides_with_ghost()  # Вызов функции коллизии с приведением

        if player.collides_with(fruit):
            player.collides_with_fruit()
            fruit.can_you_eat_me = False
            fruit.rect.x, fruit.rect.y = 0, 0
            count_score += 50

        if player.edge == 0:  # Проверка, что пакман не находится на телепорте, а иначе index out of range
            player.cell_x = player.center[0] // 48
            player.cell_y = player.center[1] // 48

            ppp = player.check_score(field[player.cell_y][player.cell_x], screen, count_score, font)  # Обработка точек

            field[player.cell_y][player.cell_x].isDot = ppp[0]
            count_score = ppp[1]

        player.process_logic(data, field[player.cell_y][player.cell_x], field)  # Логика движения пакмана

        if player.can_you_touch_me:  # Проверка, что пакмана можно убить
            player.process_animation_move()  # Проигрывание анимации движения
        else:
            if sound_flag:
                dying_sound()
                sound_flag = 0
            player.process_animation_die()  # Проигрывание анимации смерти

        player.process_draw(screen)  # Отрисоква пакмана

        if not ghost_1.rip:
            ghost_1.movement_logic(data, player)
            ghost_1.process_logic()
            ghost_1.process_draw(screen)
        if not ghost_2.rip:
            ghost_2.movement_logic(data, player)
            ghost_2.process_logic()
            ghost_2.process_draw(screen)
        if not ghost_3.rip:
            ghost_3.process_draw(screen)
            ghost_3.movement_logic(data, player)
            ghost_3.process_logic()
        if not ghost_4.rip:
            ghost_4.movement_logic(data, player)
            ghost_4.process_logic()
            ghost_4.process_draw(screen)

        if fruit.can_you_eat_me:
            fruit.process_draw(screen)

        ghost_1.animation()
        ghost_2.animation()
        ghost_3.animation()
        ghost_4.animation()

        if player.animation_delay():  # Задержка проигрывания анимации смерти
            restart()  # Рестарт сцены

        image = pygame.image.load('images/pc_right_eat.png')
        image = pygame.transform.scale(image, (48, 48))
        image2 = pygame.image.load('images/fruit1.png')
        if player.HP >= 1:
            screen.blit(image, (0, 0))
        if player.HP >= 2:
            screen.blit(image, (50, 0))
        if player.HP >= 3:
            screen.blit(image, (100, 0))
        if player.HP <= 0:
            if player.animation_delay():
                return True, count_score

        if count_score >= 2500:
            return False, count_score

        if player.BERRIES >= 1:
            screen.blit(image2, (5, 965))
        if player.BERRIES >= 2:
            screen.blit(image2, (55, 965))
        if player.BERRIES >= 3:
            screen.blit(image2, (105, 965))
        pygame.display.update()
        pygame.display.flip()
    sys.exit()
    f.close()


if __name__ == '__main__':
    game()
