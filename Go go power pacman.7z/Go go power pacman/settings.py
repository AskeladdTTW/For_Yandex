import sys
from sounds import change_volume
from init import *

size = width, height = 768, 1008
black = 0, 0, 0
blue = 0, 0, 255
white = 255, 255, 255

difficulty = difficulty


class Button:
    def __init__(self, text, chosen, x, y, w, h):
        self.text = text
        self.chosen = chosen
        self.width = w
        self.height = h
        self.x = x
        self.y = y
        self.font = pygame.font.SysFont('Courier New', 23)
        self.font_color = white

    def draw(self, screen):
        if self.chosen:
            pygame.draw.rect(screen, self.font_color, (self.x, self.y, self.width, self.height), 2)
        text_surface = self.font.render(self.text, False, self.font_color)
        screen.blit(text_surface, (self.x + 10, self.y + 10))


class Control(Button):

    def __init__(self, text, chosen, x, y, w, h, pict):
        super().__init__(text, chosen, x, y, w, h)
        self.pict = pygame.image.load(pict)
        self.pict = pygame.transform.scale(self.pict, (150, 170))
        self.rect = self.pict.get_rect()

    def draw(self, screen):
        if self.chosen:
            pygame.draw.rect(screen, self.font_color, (self.x, self.y, self.rect.width, self.rect.height), 2)
        screen.blit(self.pict, (self.x, self.y, self.rect.width, self.rect.height))

    def is_pressed(self, mouse):
        if self.x <= mouse[0] <= self.x + self.width and self.y <= mouse[1] <= self.y + self.height:
            return True


# Бывший main
def settings():
    global difficulty
    pygame.init()
    pygame.font.init()
    screen = pygame.display.set_mode(size)
    game_over = False
    open_settings = True
    # 1 - easy, 2 - normal, 3 - hard, ещё можно сделать 0 - вообще без агра, но хз зачем
    volume = 100
    volume_inc = 0
    settings_font = pygame.font.SysFont('Courier New', 23)

    btn_arrow = Control('', True, 60, 350, 100, 100, 'images/menu/arrows.png')
    btn_wasd = Control('', False, 300, 350, 100, 100, 'images/menu/wasd.png')

    btn_sound_x, btn_sound_y = 60, 200
    sound_btn = Button('Звук:', False, btn_sound_x, btn_sound_y, 80, 50)
    left_arrow_btn = Button('<', True, btn_sound_x + 80 + 5, btn_sound_y, 35, 50)
    right_arrow_btn = Button('>', True, btn_sound_x + 80 + 5 + 35 + 5, btn_sound_y, 35, 50)

    btn_difficulty_x, btn_difficulty_y = btn_sound_x, btn_sound_y + 60
    difficulty_btn = Button('Сложность:', False, btn_difficulty_x, btn_difficulty_y, 150, 50)
    easy_btn = Button('Easy', False, btn_difficulty_x + 150 + 5, btn_difficulty_y, 70, 50)
    normal_btn = Button('Normal', False, btn_difficulty_x + 150 + 5 + 70 + 5, btn_difficulty_y, 95, 50)
    hard_btn = Button('Hard', False, btn_difficulty_x + 150 + 5 + 70 + 5 + 95 + 5, btn_difficulty_y, 75, 50)
    if difficulty == 1:
        easy_btn.chosen = True
    if difficulty == 2:
        normal_btn.chosen = True
    if difficulty == 3:
        hard_btn.chosen = True

    return_btn_x, return_btn_y = 700, 200
    return_btn_img = pygame.image.load('images/return_btn.png')

    while not game_over:
        mouse = pygame.mouse.get_pos()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if btn_wasd.is_pressed(mouse):
                    btn_wasd.chosen = True
                    btn_arrow.chosen = False
                    player.key_up = pygame.K_w
                    player.key_down = pygame.K_s
                    player.key_right = pygame.K_d
                    player.key_left = pygame.K_a
                if btn_arrow.is_pressed(mouse):
                    btn_wasd.chosen = False
                    btn_arrow.chosen = True
                    player.key_up = pygame.K_UP
                    player.key_down = pygame.K_DOWN
                    player.key_right = pygame.K_RIGHT
                    player.key_left = pygame.K_LEFT
                if btn_sound_y <= event.pos[1] <= btn_sound_y + sound_btn.height:
                    if btn_sound_x + sound_btn.width + 5 <= event.pos[
                        0] <= btn_sound_x + sound_btn.width + 5 + left_arrow_btn.width:
                        volume_inc = -1
                    elif btn_sound_x + sound_btn.width + 5 + left_arrow_btn.width + 5 <= event.pos[
                        0] <= btn_sound_x + sound_btn.width + 5 + left_arrow_btn.width + 5 + right_arrow_btn.width:
                        volume_inc = 1
                if btn_difficulty_y <= event.pos[1] <= btn_difficulty_y + difficulty_btn.height:
                    if btn_difficulty_x + difficulty_btn.width + 5 <= event.pos[
                        0] <= btn_difficulty_x + difficulty_btn.width + 5 + easy_btn.width:
                        easy_btn.chosen = True
                        normal_btn.chosen, hard_btn.chosen = False, False
                        difficulty = 1
                    elif btn_difficulty_x + difficulty_btn.width + 5 + easy_btn.width + 5 <= event.pos[
                        0] <= btn_difficulty_x + difficulty_btn.width + 5 + easy_btn.width + 5 + normal_btn.width:
                        normal_btn.chosen = True
                        easy_btn.chosen, hard_btn.chosen = False, False
                        difficulty = 2
                    elif btn_difficulty_x + difficulty_btn.width + 5 + easy_btn.width + 5 + normal_btn.width + 5 <= \
                            event.pos[
                                0] <= btn_difficulty_x + difficulty_btn.width + 5 + easy_btn.width + 5 + normal_btn.width + 5 + hard_btn.width:
                        hard_btn.chosen = True
                        normal_btn.chosen, easy_btn.chosen = False, False
                        difficulty = 3
                if return_btn_y <= event.pos[1] <= return_btn_y + 22 and return_btn_x <= event.pos[
                    0] <= return_btn_x + 50:
                    # open_settings = False
                    game_over = True
            if event.type == pygame.MOUSEBUTTONUP:
                volume_inc = 0
        screen.fill(black)

        ghost_2.set_difficulty(difficulty)
        ghost_3.set_difficulty(difficulty)
        ghost_4.set_difficulty(difficulty)

        if open_settings:
            if not (0 <= volume + volume_inc <= 100):
                volume_inc = 0
            volume += volume_inc
            change_volume(volume)

            sound_btn.draw(screen)
            left_arrow_btn.draw(screen)
            right_arrow_btn.draw(screen)
            text_surface = settings_font.render(str(volume), False, white)
            screen.blit(text_surface, (btn_sound_x + 80 + 5 + 35 + 5 + 35 + 5 + 10, btn_sound_y + 10))
            difficulty_btn.draw(screen)
            easy_btn.draw(screen)
            normal_btn.draw(screen)
            hard_btn.draw(screen)
            btn_arrow.draw(screen)
            btn_wasd.draw(screen)
            screen.blit(return_btn_img, (return_btn_x, return_btn_y))

        pygame.display.flip()
        pygame.time.wait(10)
