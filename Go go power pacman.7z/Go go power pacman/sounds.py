import pygame
import os

GAME_FOLDER = os.path.dirname(__file__)
pygame.mixer.init()


def play_sound(file):
    if not pygame.mixer.music.get_busy():
        pygame.mixer.music.load(os.path.join(GAME_FOLDER, file))
        pygame.mixer.music.play()


def dots_eating_sound():
    play_sound("music/Dots_eating_sound.ogg")


def eating_fruit_sound():
    play_sound("music/Cherry_eating_sound.ogg")


def dying_sound():
    play_sound("music/Dying_sound.ogg")


def eating_ghost_sound():
    play_sound("music/Eating_ghost_sound.ogg")


def opening_sound():
    play_sound("music/Mighty-Morphin-Power-Rangers-Full-Theme-Song.ogg")


def change_volume(volume):
    pygame.mixer.music.set_volume(volume / 100)


def go_go_power_rangers_sound():
    play_sound("music/Go_Go_Power_Rangers.ogg")
